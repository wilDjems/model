# Dogfight
Comment ça marche ?
- Bien.