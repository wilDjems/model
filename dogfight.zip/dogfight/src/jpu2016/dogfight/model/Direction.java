package jpu2016.dogfight.model;

public enum Direction {
	UP,
	RIGHT,
	DOWN,
	LEFT;
}