package jpu2016.dogfight.model;

import java.awt.Image;

public interface IArea {
	public Dimension getDimension();
	public Image getImage();
}
