package jpu2016.gameframe;

import java.awt.event.KeyEvent;

public interface IEventPerformer 
{
	public void eventPerform(KeyEvent keyCode);
}
